<?php

	$id			=$_REQUEST['id'];
	$password	=$_REQUEST['Pword'];
	$cpassword	=$_REQUEST['cPword'];
	$name		=$_REQUEST['name'];
    $usertype	=$_REQUEST['utype'];
	
	echo $id ;
	echo $password ;
	echo $cpassword ;
	echo $name ;
	echo $usertype;

?>